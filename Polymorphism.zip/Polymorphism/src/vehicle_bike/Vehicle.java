package vehicle_bike;

 class Vehicle {
	 Vehicle(){
		System.out.println("Vehicle is created");
	}
	 Vehicle(int a){
		 System.out.println("Vehicle is created"+a);
	 }
	 void run() {
	 System.out.println("Vehicle is runing");
	 }
	 void r1() {
		 System.out.println("method r1 is called");
	 }
	 void r2() {
		 System.out.println("method r2 is called ");
	 }
}
