package shape;

public interface Shape1 {
//declare fields: public static final by default
	//khong co method
	//chi co abstract method
	public  void input();
	public  void output();
	public  Double area();
	public  Double circumference();
	
	//khong co main method
}
