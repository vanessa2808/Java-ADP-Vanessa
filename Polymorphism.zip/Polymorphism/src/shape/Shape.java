package shape;
import java.util.Scanner;
public abstract class  Shape {
	//declare fields: private,protected,public,default,static,final
	//co cac constructor
	public Shape() {

	}
	// method body
	public void A() {
		System.out.println("A");
	}
	//abstract method
	public abstract void input();
	public abstract void output();
	//public abstract void are();
	//public abstract void circumference();
	//main method
	//khong the new chinh no
	public static void main(String[]args) {
		
	}
}



