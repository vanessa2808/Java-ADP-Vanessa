package examplestring;

public class Simple7_SubString {
	public static void main(String[]args) {
		String s="Sachin Tendulkar";
		System.out.println(s.substring(6));
		System.out.println(s.substring(0, 6));
	}
}
