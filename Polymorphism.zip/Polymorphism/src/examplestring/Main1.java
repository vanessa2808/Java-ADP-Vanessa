package examplestring;

public class Main1 {

	public static void main(String[] args) {
		String s="Duy Tan ";
		s=s.concat("University");
		System.out.println(s);
	}
}
