package examplestring;

public class Simple10_StartWith {
	public static void main(String[]args) {
		String s="Sachin";
		System.out.println(s.startsWith("Sa"));		//true
		System.out.println(s.startsWith("n"));   //true
	}
}
