package examplestring;

public class Simple6_Concatenation {
	public static void main(String[] args) {
		String s=50+30+"Sanchin"+40+40;
		System.out.println(s);
	}
}