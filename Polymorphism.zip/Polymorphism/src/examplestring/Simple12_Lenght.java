package examplestring;

public class Simple12_Lenght {
	public static void main(String[]args) {
		String s="Sachin";
		System.out.println(s.length());  //6
	}
}
