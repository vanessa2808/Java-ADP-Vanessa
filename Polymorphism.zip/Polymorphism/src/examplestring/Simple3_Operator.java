package examplestring;

public class Simple3_Operator {

	public static void main(String[] args) {
		String s1="Sanchin";
		String s2="Sanchin";
		String s3=new String("Sanchin");
		
		System.out.println(s1==s2);
		System.out.println(s1==s3);
	}
}
