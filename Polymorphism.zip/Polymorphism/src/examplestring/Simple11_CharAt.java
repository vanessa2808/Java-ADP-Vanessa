package examplestring;

public class Simple11_CharAt {
	public static void main(String[]args) {
		String s="Sachin";
		System.out.println(s.charAt(0));
		System.out.println(s.charAt(3));
	}
}
