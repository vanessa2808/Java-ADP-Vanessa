package examplestring;

public class Simple5_Concatenation {
	public static void main(String[]args) {
		String s="Sanchi"+" Tendulkar";
		System.out.println(s);
	}
}
