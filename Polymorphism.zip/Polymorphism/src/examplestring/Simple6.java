package examplestring;

public class Simple6 {
	public static void main(String[]args) {
		String s1="Sanchi";
		String s2="Tendulkar";
		String s3=s1.concat(s2);
		System.out.println(s3);
	}
}
