package examplestring;

public class B5 {

	public static void main(String[] args) {
		StringBuilder sb=new StringBuilder("Hello");
		sb.reverse();
		System.out.println(sb); //print olleH

	}

}
