package examplestring;

public class Main {

	public static void main(String[] args) {
		String s=" Duy Tan";
		s.concat("University");
		// concat() method appends the string at the end
		System.out.println(s);
	}

}
