package examplestring;

public class Simple9_Trim {

	public static void main(String[] args) {
		String s="Sachin ";
		System.out.println(s);   //Sachin
		System.out.println(s.trim()); //Sachin
	}

}
